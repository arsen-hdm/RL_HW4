base_url=https://raw.githubusercontent.com/hrnr/m-explore-extra/master/map_merge
wget ${base_url}/gmapping_maps/2012-01-28-11-12-01.pgm -P build/multirobot_map_merge
wget ${base_url}/gmapping_maps/2011-08-09-12-22-52.pgm -P build/multirobot_map_merge
wget ${base_url}/hector_maps/map05.pgm -P build/multirobot_map_merge
wget ${base_url}/hector_maps/map00.pgm -P build/multirobot_map_merge