^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package explore_lite
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2021-08-01)
------------------
* First working port in ros2 foxy
* Contributors: Carlos Alvarez, Juan Gavlis